/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
//#include "audio_player.h"
#include "wav.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SAI_HandleTypeDef hsai_BlockA1;
DMA_HandleTypeDef hdma_sai1_a;

SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
FIL file;                  // FIL object for FatFS
uint32_t file_read_pos = 0;
uint32_t bytes_remaining = 0;

#define AUDIO_BUFFER_BYTES 4096
#define AUDIO_DMA_HALF (AUDIO_BUFFER_BYTES/2)

static uint8_t audio_buffer[AUDIO_BUFFER_BYTES];
static volatile uint8_t half_transfer_flag = 0;
static volatile uint8_t full_transfer_flag = 0;

static FIL wav_file;
static WAV_Info wavinfo;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SAI1_Init(void);
/* USER CODE BEGIN PFP */
void myprintf(const char *fmt, ...);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
UINT sd_read_bytes(uint8_t *buf, UINT len)
{
    UINT br;
    FRESULT res = f_read(&file, buf, len, &br);
    return br;   // return number of bytes actually read
}

void myprintf(const char *fmt, ...) {
  static char buffer[256];
  va_list args;
  va_start(args, fmt);
  vsnprintf(buffer, sizeof(buffer), fmt, args);
  va_end(args);

  int len = strlen(buffer);
  HAL_UART_Transmit(&huart2, (uint8_t*)buffer, len, -1);

}

void HAL_SAI_TxHalfCpltCallback(SAI_HandleTypeDef *hsai) {
    (void)hsai;
    half_transfer_flag = 1;
}

void HAL_SAI_TxCpltCallback(SAI_HandleTypeDef *hsai) {
    (void)hsai;
    full_transfer_flag = 1;
}
/* refill_half_buffer:
 *  half == 0 -> fill first half (audio_buffer[0 .. half-1])
 *  half == 1 -> fill second half (audio_buffer[half .. end-1])
 *
 * We assume 16-bit PCM little-endian interleaved stereo or mono.
 * If WAV is mono, duplicate samples to produce stereo for MAX98357A stereo input.
 */
static void refill_half_buffer(uint8_t half) {
    uint8_t *ptr = audio_buffer + (half ? AUDIO_DMA_HALF : 0);
    uint32_t bytes_to_fill = AUDIO_DMA_HALF;

    if (wavinfo.num_channels == 2) {
        // stereo 16-bit, data layout matches I2S (Left/Right interleaved)
        sd_read_bytes(ptr, bytes_to_fill);
    } else if (wavinfo.num_channels == 1) {
        // mono: read 16-bit samples and duplicate them L/R
        // read bytes_to_fill/2 bytes of mono PCM -> after duplication become bytes_to_fill
        uint32_t samples_needed = (bytes_to_fill / 2); // number of 16-bit output samples (stereo)
        // we'll read samples_needed/2 mono samples, then expand
        // safer approach: read a chunk into a temp buffer and expand
        uint32_t mono_bytes = samples_needed * 2 / 2; // because each mono sample will become two 16-bit words
        // simpler: read samples_needed mono samples and then duplicate in-place into ptr
        uint8_t tmp[AUDIO_DMA_HALF/2];
        UINT got = sd_read_bytes(tmp, mono_bytes);
        // duplicate
        for (uint32_t i = 0, out = 0; i < got; i += 2) {
            // copy 2 bytes twice (left and right)
            ptr[out++] = tmp[i];
            ptr[out++] = tmp[i+1];
            ptr[out++] = tmp[i];
            ptr[out++] = tmp[i+1];
        }
        // if we read less than needed, pad remainder with zeros
        if (got < mono_bytes) {
            uint32_t out_pos = (got/2) * 4;
            memset(ptr + out_pos, 0, bytes_to_fill - out_pos);
        }
    } else {
        // unsupported channels -> silence
        memset(ptr, 0, bytes_to_fill);
    }
}

/* start_wav_playback:
 *  - opens file
 *  - parses WAV header
 *  - positions file pointer at start of PCM data
 *  - sets bytes_remaining
 */
static int start_wav_playback(const char *filename) {
    FRESULT fr;
    UINT br;
    fr = f_open(&wav_file, filename, FA_READ);
    if (fr != FR_OK) return -1;
    if (wav_parse_header(&wav_file, &wavinfo) != 0) {
        f_close(&wav_file);
        return -2;
    }

    // we only support 16-bit in this example (easily extendable)
    if (wavinfo.bits_per_sample != 16) {
        // not supported in this sample
        f_close(&wav_file);
        return -3;
    }

    // position file pointer at PCM data start
    f_lseek(&wav_file, wavinfo.data_start);
    file_read_pos = wavinfo.data_start;
    bytes_remaining = wavinfo.data_bytes;

    // Configure SAI/I2S audio format if needed - simple example:
    // If you configured SAI sample rate in CubeMX to match the file, you're OK.
    // Advanced: reconfigure SAI audio frequency and clocks at runtime to match wavinfo.sample_rate.
    // For now we assume the SAI clock matches the WAV sample_rate.

    return 0;
}

FIL mp3_file;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
/* LCD configuration code end ---------------------------------------------------- */
LCD_Init();
LCD_Clear();
LCD_Print(Waiting...);

start_wav_playback("0:/test.wav");

LCD_Clear();
LCD_Print("Playing");
LCD_Print(current_filename);

/* LCD configuration code end ---------------------------------------------------- */


  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_FATFS_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();
  MX_SAI1_Init();
  /* USER CODE BEGIN 2 */
  if (f_mount(&USERFatFS, USERPath, 1) != FR_OK)
  {
      Error_Handler();
  }

  if (start_wav_playback("0:/test.wav") != 0) {
      Error_Handler();
  }

  // Pre-fill buffer before starting DMA
  refill_half_buffer(0);
  refill_half_buffer(1);

  HAL_SAI_Transmit_DMA(&hsai_BlockA1, (uint8_t*)audio_buffer, AUDIO_BUFFER_BYTES/2);

//  myprintf("\r\n~ SD card demo by dylan ~\r\n\r\n");
//
//    HAL_Delay(1000); //a short delay is important to let the SD card settle
//
//    //some variables for FatFs
//    FATFS FatFs; 	//Fatfs handle
//    FIL fil; 		//File handle
//    FRESULT fres; //Result after operations
//
//    //Open the file system
//    fres = f_mount(&FatFs, "", 1); //1=mount now
//    if (fres != FR_OK) {
//  	myprintf("f_mount error (%i)\r\n", fres);
//  	while(1);
//    }
//
//    //Let's get some statistics from the SD card
//    DWORD free_clusters, free_sectors, total_sectors;
//
//    FATFS* getFreeFs;
//
//    fres = f_getfree("", &free_clusters, &getFreeFs);
//    if (fres != FR_OK) {
//  	myprintf("f_getfree error (%i)\r\n", fres);
//  	while(1);
//    }
//
//    //Formula comes from ChaN's documentation
//    total_sectors = (getFreeFs->n_fatent - 2) * getFreeFs->csize;
//    free_sectors = free_clusters * getFreeFs->csize;
//
//    myprintf("SD card stats:\r\n%10lu KiB total drive space.\r\n%10lu KiB available.\r\n", total_sectors / 2, free_sectors / 2);
//
//    //Now let's try to open file "test.txt"
//    fres = f_open(&fil, "test.txt", FA_READ);
//    if (fres != FR_OK) {
//  	myprintf("f_open error (%i)\r\n");
//  	while(1);
//    }
//    myprintf("I was able to open 'test.txt' for reading!\r\n");
//
//    //Read 30 bytes from "test.txt" on the SD card
//    BYTE readBuf[30];
//
//    //We can either use f_read OR f_gets to get data out of files
//    //f_gets is a wrapper on f_read that does some string formatting for us
//    TCHAR* rres = f_gets((TCHAR*)readBuf, 30, &fil);
//    if(rres != 0) {
//  	myprintf("Read string from 'test.txt' contents: %s\r\n", readBuf);
//    } else {
//  	myprintf("f_gets error (%i)\r\n", fres);
//    }
//
//    //Be a tidy kiwi - don't forget to close your file!
//    f_close(&fil);
//
//    //Now let's try and write a file "write.txt"
//    fres = f_open(&fil, "write.txt", FA_WRITE | FA_OPEN_ALWAYS | FA_CREATE_ALWAYS);
//    if(fres == FR_OK) {
//  	myprintf("I was able to open 'write.txt' for writing\r\n");
//    } else {
//  	myprintf("f_open error (%i)\r\n", fres);
//    }
//
//    //Copy in a string
//    strncpy((char*)readBuf, "a new file is made!", 19);
//    UINT bytesWrote;
//    fres = f_write(&fil, readBuf, 19, &bytesWrote);
//    if(fres == FR_OK) {
//  	myprintf("Wrote %i bytes to 'write.txt'!\r\n", bytesWrote);
//    } else {
//  	myprintf("f_write error (%i)\r\n");
//    }
//
//    //don't forget to close your file!
//    f_close(&fil);
//
//    //We're done, so de-mount the drive
//    f_mount(NULL, "", 0);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (half_transfer_flag) {
	      half_transfer_flag = 0;
	      refill_half_buffer(0);
	  }
	  if (full_transfer_flag) {
	      full_transfer_flag = 0;
	      refill_half_buffer(1);
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SAI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SAI1_Init(void)
{

  /* USER CODE BEGIN SAI1_Init 0 */

  /* USER CODE END SAI1_Init 0 */

  /* USER CODE BEGIN SAI1_Init 1 */

  /* USER CODE END SAI1_Init 1 */
  hsai_BlockA1.Instance = SAI1_Block_A;
  hsai_BlockA1.Init.AudioMode = SAI_MODEMASTER_TX;
  hsai_BlockA1.Init.Synchro = SAI_ASYNCHRONOUS;
  hsai_BlockA1.Init.OutputDrive = SAI_OUTPUTDRIVE_DISABLE;
  hsai_BlockA1.Init.NoDivider = SAI_MASTERDIVIDER_ENABLE;
  hsai_BlockA1.Init.FIFOThreshold = SAI_FIFOTHRESHOLD_EMPTY;
  hsai_BlockA1.Init.AudioFrequency = SAI_AUDIO_FREQUENCY_44K;
  hsai_BlockA1.Init.SynchroExt = SAI_SYNCEXT_DISABLE;
  hsai_BlockA1.Init.MonoStereoMode = SAI_MONOMODE;
  hsai_BlockA1.Init.CompandingMode = SAI_NOCOMPANDING;
  hsai_BlockA1.Init.TriState = SAI_OUTPUT_NOTRELEASED;
  if (HAL_SAI_InitProtocol(&hsai_BlockA1, SAI_I2S_STANDARD, SAI_PROTOCOL_DATASIZE_16BIT, 2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SAI1_Init 2 */

  /* USER CODE END SAI1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  hspi1.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA2_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Channel1_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : SD_CS_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
